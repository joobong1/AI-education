1. 일자순으로 진행
2. hg-mldl-master : 실습 파일
3. 혼공머신_강의계획서_v0.5 : 실습 파일 링크(일자별)
4. ppt는 구글 드라이브에 있습니다.
	링크 : https://drive.google.com/drive/folders/1s9gLaXbvnR00z4YlSNnQcpyGVZJ4V_ec?usp=sharing
